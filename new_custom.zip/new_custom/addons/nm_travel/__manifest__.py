# -*- coding: utf-8 -*-
{
    'name': 'Nutric Travel Management',
    'version': '16.0.1',
    'author': 'ecompazz it sdn bhd',
    'maintainers': ['aziz'],
    'summary': 'Travel management for BD team to plan and manage budgets, expenses and claims',
    'category': 'Expenses',
    'depends': ['hr_expense','event','hr','sale'],
    'data': [
        'security/nm_travel_security.xml',
        'security/ir.model.access.csv',
        'views/nm_travel_views.xml',
        'views/menuitems_views.xml',
        ],
}