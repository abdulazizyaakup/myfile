# -*- coding: utf-8 -*-

from odoo import fields, models, api

class NmTravel(models.Model):
    _name = 'nm.travel'

    def _compute_employee_id(self):
        employee_id = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
        return employee_id.id

    name = fields.Char(string="Name")
    is_event = fields.Char(string="Travel Purpose")
    event_id = fields.Many2one(comodel_name='event.event', string="Event")
    venue = fields.Char(string="Venue")
    start_date = fields.Date(string="Start Date")
    end_date = fields.Date(string="End Date")
    organizer_id = fields.Many2one('res.partner',string="Organizer")
    user_id = fields.Many2one(
        comodel_name='res.users',
        string="Requested By",
        compute='_compute_user_id',
        store=True, readonly=False, precompute=True, index=True,
        tracking=2,
        default=lambda self: self.env.user,)
    related_employee_id = fields.Many2one(comodel_name='hr.employee',string="Employee",default=_compute_employee_id)
    department_id = fields.Many2one(comodel_name='hr.department',string="Department")
    # transportation_category = fields.Many2one(comodel='transportation.category',string="Transportation Category")
    


    @api.onchange('event_id')
    def _get_event_details(self):
        if self.event_id:
            for m in self.event_id:
                self.venue = m.address_id.street or ''
                self.organizer_id = m.organizer_id.id
                self.start_date = m.date_begin
                self.end_date = m.date_end

    @api.onchange('user_id')
    def get_employee_id(self):
        if self.user_id:
            emp_id = self.env['hr.employee'].search([('user_id', '=', self.user_id.id)], limit=1)
            self.related_employee_id = emp_id

    @api.onchange('related_employee_id')
    def _compute_department_id(self):
        if self.related_employee_id:
            self.department_id = self.related_employee_id.department_id.id
