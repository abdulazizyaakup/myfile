# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class AccMoveInherit(models.Model):
    _inherit = 'account.move'

    package_id = fields.Many2one('product.template', domain=['is_pack','==',True],string="Select Package")
    sale_package_type = fields.Selection(
        selection=[
            ('fsp', "FSP"),
            ('nup', "NUP"),
        ],
        string="Package Type")
    # package_id = fields.Many2one('product.template', string="Product Package")

    @api.depends('company_id', 'invoice_filter_type_domain')
    def _compute_suitable_journal_ids(self):
        for m in self:
            journal_type = m.invoice_filter_type_domain or 'general'
            company_id = m.company_id.id or self.env.company.id
            domain = [('company_id', '=', company_id), ('type', '=', journal_type)]
            m.suitable_journal_ids = self.env['account.journal'].search([])


class AccPackMoveLine(models.Model):
    _inherit = 'account.move.line'

    fixed_qty = fields.Boolean("Fixed Qty",default=False)