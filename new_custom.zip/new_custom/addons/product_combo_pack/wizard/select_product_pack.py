# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

""" Class to define and add new product pack on sales order"""
class SelectPack(models.TransientModel):
    _name = 'select.product.pack'
    _rec_name = 'product_id'
    _description = 'Add product pack to sale order'

    product_id = fields.Many2one('product.product', string='Select Pack', domain=[('is_pack', '=', True)],                                required=True)
    quantity = fields.Integer('Quantity', default=0, required=True)

    def add_pack_order(self):
        active_id = self._context.get('active_id')
        if active_id:
            sale_id = self.env['sale.order'].browse(active_id)
            name = self.product_id.display_name
            if self.product_id.description_sale:
                name += '\n' + self.product_id.description_sale

            sale_id.write({'package_id':self.product_id.id,'sale_package_type':self.product_id.package_type})
            order_lines = []
            val = (0, 0, {
                'display_type': 'line_section',
                'name': self.product_id.name,
            })
            order_lines.append(val)
            sale_id.update({'order_line': order_lines}) 
            for pp in self.product_id:
                for p in pp.pack_products_ids:
                    self.env['sale.order.line'].create({
                        'product_id': p.product_id.id,
                        'price_unit': p.price,
                        'product_uom': p.product_id.uom_id.id,
                        'product_uom_qty': p.quantity,
                        'order_id': sale_id.id,
                        'name': name,
                        'fixed_qty': p.fixed_qty or False,
                        'tax_id': p.product_id.taxes_id.ids
                    })

    @api.constrains('quantity')
    def _check_positive_qty(self):
        if any([ml.quantity < 0 for ml in self]):
            raise ValidationError(_('You can not enter negative quantities.'))




""" Class to define and add new product pack on customer invoices"""
class SelectPack2(models.TransientModel):
    _name = 'select.product.pack2'
    _rec_name = 'product_id'
    _description = 'Add product pack to customer invoice'

    product_id = fields.Many2one('product.product', string='Select Pack', domain=[('is_pack', '=', True)],                                required=True)
    quantity = fields.Integer('Quantity', default=0, required=True)

    def add_pack_order2(self):
        active_id = self._context.get('active_id')
        if active_id:
            inv_id = self.env['account.move'].browse(active_id)
            name = self.product_id.display_name
            if self.product_id.description_sale:
                name += '\n' + self.product_id.description_sale

            inv_id.write({'package_id':self.product_id.id,'sale_package_type':self.product_id.package_type})
            order_lines = []
            val = (0, 0, {
                'display_type': 'line_section',
                'name': self.product_id.name,
            })
            order_lines.append(val)
            inv_id.update({'invoice_line_ids': order_lines}) 
            for pp in self.product_id:
                for p in pp.pack_products_ids:
                    self.env['account.move.line'].create({
                        'product_id': p.product_id.id,
                        'price_unit': p.price,
                        'product_uom_id': p.product_id.uom_id.id,
                        'quantity': p.quantity,
                        'move_id': inv_id.id,
                        'name': name,
                        'fixed_qty': p.fixed_qty or False,
                        'tax_ids': p.product_id.taxes_id.ids
                    })

    @api.constrains('quantity')
    def _check_positive_qty(self):
        if any([ml.quantity < 0 for ml in self]):
            raise ValidationError(_('You can not enter negative quantities.'))