from . import partner
# from . import res_config
