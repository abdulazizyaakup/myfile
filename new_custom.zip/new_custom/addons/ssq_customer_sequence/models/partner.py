from odoo import fields, models, api

class ResPartner(models.Model):
    _inherit = "res.partner"

    code = fields.Char("Membership ID")
    referral_code = fields.Char("Referral Code")
    national_id = fields.Char("National ID")
    signup_code = fields.Char("Signup Code")
    credit_wallet = fields.One2many(
        comodel_name='partner.wallet',
        inverse_name='wallet_id',
        string="Wallet",
        copy=True, auto_join=True)
    member_ids = fields.Many2many(
        comodel_name='member.type',
        relation='member_type_rel', column1='partner_id', column2='type_id',
        string="Member Type")

class MemberWallet(models.Model):
    _name = "partner.wallet"


    wallet_id = fields.Many2one(
        comodel_name='res.partner',
        string="Wallet Reference",
        required=True, ondelete='cascade', index=True, copy=False)
    # member_id = fields.Many2one('res.partner', string="Member")
    credit_in_date = fields.Date(string='Date', required=True, readonly=False)
    credit_amount = fields.Float(string="Credit Amount")
    debit_amount = fields.Float(string="Debit Amount")
    balance = fields.Float(string="Available Balance")
    previous_amount = fields.Float(string="Previous Amount")

    # @api.depends('credit_amount','debit_amount')
    # def _calculate_balance(self):
        



    # is_seq_auto_create = fields.Boolean(compute="_compute_sequence_creation")

    # def _compute_sequence_creation(self):
    #     for partner in self:
    #         partner.is_seq_auto_create = (
    #             self.env["ir.config_parameter"].sudo().get_param("ssq_customer_sequence.is_seq_auto_create")
    #         )

    # @api.model
    # def create(self, vals):
    #     partner = super().create(vals)
    #     if partner.customer_rank > 0 and partner.is_seq_auto_create:
    #         partner.code = self.env["ir.sequence"].next_by_code("code.res.partner")
    #     return partner

    # def create_code(self):
    #     self.code = self.env["ir.sequence"].next_by_code("code.res.partner")
