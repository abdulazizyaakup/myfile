This new workflow can be activated by company and by supplier.

To activate the new workflow by company:

#. Go to 'Purchase > Configuration > Settings'.
#. In the *Orders* section you can set the *State 'Approved' in Purchase
   Orders*.

To activate the new workflow by supplier:

#. Open the supplier form view.
#. In the *Purchase* section in the *Sales & Purchases* tab the field
   *Purchase requires second approval* allows you to select the policy to
   apply for the current supplier. 'Never' | 'Always' | 'Based on company policy'
