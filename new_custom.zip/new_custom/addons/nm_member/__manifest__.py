# -*- coding: utf-8 -*-
{
    'name': 'Nutric Member Management',
    'version': '16.0.1',
    'author': 'ecompazz it sdn bhd',
    'maintainers': ['aziz'],
    'summary': 'Member Profile management',
    'category': 'Sales',
    'depends': ['base'],
    'data': [
        'security/nm_member_security.xml',
        'security/ir.model.access.csv',
        'views/nm_member_views.xml',
        'views/menuitems_views.xml',
        ],
}