# -*- coding: utf-8 -*-

from odoo import fields, models, api

class NmQuestion(models.Model):
    _name = 'nm.question'

    name = fields.Char(string='Question')


# class NmCountryCode(models.Model):
#     _name = 'nm.ccode'

#     name = fields.Char(string='Code')
#     country_id = fields.Many2one(comodel_name='res.country', string='Country')

class NmMemberJob(models.Model):
    _name = 'nm.memberjob'

    name = fields.Char(string='Job')

class NmMember(models.Model):
    _name = 'nm.member'

    name = fields.Char(string='Name')
    m_name = fields.Char(string='Legacy Name')
    m_id = fields.Integer(string='Legacy ID')
    m_memtradingname = fields.Char(string='Legacy Login Name')
    m_ic = fields.Char(string='Legacy IC')
    q_id = fields.Many2one(comodel_name='nm.question')
    m_ans = fields.Char(string='Answer')
    m_password = fields.Char(string='Password')
    m_gender = fields.Selection(
        [("Male", "Male"),("Female", "Female"),],string='Gender')
    m_race = fields.Selection(
        [("Malay", "Malay"),("Chinese", "Chinese"),("Indian", "Indian"),("Others", "Others")],string='Race')
    m_dob = fields.Date(string='Date of Birth')
    m_email = fields.Char(string='Email')
    m_tel_mob = fields.Char(string='Mobile No.')
    m_tel_hse = fields.Char(string='Home No.')
    m_tel_off = fields.Char(string='Office No.')
    m_tel_fax = fields.Char(string='Fax')
    c_code = fields.Char(string='C Code')
    # country_code = fields.Many2one(comodel_name='country.code',string='Country Code')
    m_add1 = fields.Char(string='Street')
    m_add2 = fields.Char(string='Street 2')
    m_city = fields.Char(string='City')
    m_postcode = fields.Char(string='Postcode')
    m_state = fields.Many2one(comodel_name='res.state',string='State')
    m_status = fields.Char(string='Status')
    m_datejoined = fields.Datetime(string='Date Joined')
    m_dateactivated = fields.Datetime(string='Date Deactivated')
    m_nextrenewdate = fields.Datetime(string='Next Renewal Date')

    refm_id = fields.Many2one(comodel_name='nm.member', string='Referral')
    # m_fpa = fields.??
    m_bpromo = fields.Integer(string='Birthday Promo')
    m_idrepeatsales = fields.Boolean(string='Repeat Sales?')
    m_idrepeatsalesdate = fields.Datetime(string='Repeat Sale Date')
    m_uplinemid = fields.Integer(string='Upline Id')
    m_uplinetno = fields.Integer(string='Upline No')
    m_uplinepos = fields.Char('Upline Position')
    m_datesuspend = fields.Datetime(string='Date Suspended')
    m_dateterminate = fields.Datetime(string='Date Terminated')
    # m_ocid = fields.Many2one(comodel_name='nm.memberjob')
    m_npwp = fields.Char(string='Indonesia Tax No')
    m_npwpverify = fields.Char(string='Verification Status')
    m_npwpverifydate = fields.Datetime(string='Verification Date')
    # partner_id = fields.Many2one(comodel_name='res.partner', string='Related Partner')
    # user_id = fields.Many2one(comodel_name='res.users', string='Related User')





