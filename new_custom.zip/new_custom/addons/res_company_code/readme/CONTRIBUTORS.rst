* Sylvain LE GAL <https://twitter.com/legalsylvain>
* Kiril Vangelovski <kiril@lambda-is.com>
* Kevin Khao <kevin.khao@akretion.com>
